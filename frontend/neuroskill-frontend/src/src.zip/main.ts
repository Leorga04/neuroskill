import { bootstrapApplication } from '@angular/platform-browser';
import { AppComponent } from './app/app.component';
import { provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';
import { UsuariosService } from './app/services/usuarios.service'; // 👈 asegúrate de tener esto bien escrito

bootstrapApplication(AppComponent, {
  providers: [
    provideHttpClient(withInterceptorsFromDi()),
    UsuariosService // 👈 REGÍSTRALO AQUÍ
  ]
});
