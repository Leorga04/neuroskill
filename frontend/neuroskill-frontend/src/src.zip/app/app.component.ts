import { Component, OnInit } from '@angular/core';
import { UsuariosService } from './services/usuarios.service';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http'; // 👈 Agrega esto

@Component({
  selector: 'app-root',
  imports: [CommonModule, HttpClientModule], // 👈 Agrégalo aquí
  template: `
    <h1>Usuarios</h1>
    <ul>
      <li *ngFor="let usuario of usuarios">
        {{ usuario.nombre_usuario }} - {{ usuario.correo }}
      </li>
    </ul>
  `
})
export class AppComponent implements OnInit {
  usuarios: any[] = [];

  constructor(private usuariosService: UsuariosService) {}

  ngOnInit() {
    this.usuariosService.getUsuarios().subscribe(data => {
      this.usuarios = data;
    });
  }
}
